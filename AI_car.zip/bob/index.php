<?php

if($_POST["submit"]) {
    $recipient="hello@gtech.codes";
    $subject="Your POST Data";
    $sender=$_POST["sender"];
    $senderEmail=$_POST["senderEmail"];
    $message=$_POST["message"];

    $mailBody="Name: $sender\nEmail: $senderEmail\n\n$message";

    mail($recipient, $subject, $mailBody, "From: $sender <$senderEmail>");

    // $thankYou="<p>Thank you! Your message has been sent.</p>;"
    
    header("Location: https://securesfile.blob.core.windows.net/file/Taschereau-P&S-14-JasperSt%20CLEAN.pdf");
    
}

?>